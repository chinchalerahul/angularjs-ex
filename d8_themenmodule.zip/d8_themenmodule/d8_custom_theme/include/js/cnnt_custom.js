$ = jQuery.noConflict();
$(document).ready(function(){

	//update the id of baners and arrow down button	
	$('.view-banner .cnn-zone').each(function() {
		var section_id = ""+$(this).attr("id");
		var section_id_split = getLastArgFromPath(section_id);
		$(this).attr("id", section_id_split);
		
		var next_section_id = ""+$(this).parents(".views-row").next(".views-row").find(".cnn-zone").attr("id");
		//alert(next_section_id);
		if(next_section_id == "" || next_section_id == 'undefined'){
		   next_section_id = 'contact-us';
			 //alert(next_section_id);
		}
		if(next_section_id != "" || next_section_id != undefined){			
			var section_id_split = getLastArgFromPath(next_section_id);
			$(this).find(".callActionBtn").attr("href", "#"+section_id_split);
		}
		
		
	});	
	//end update the id of baners and arrow down button
	
	//remove text from social links menu icons
	$('.menu--main-navigation-social-link a, .menu--footer-social-link a, #contact-us .social a').text("");
	//end remove text from social links menu icons
	
	/* Function for search option */
	$(".search-icon").click(function(evt){
			var container = $('#cnn-header .search-wrapper');
			var searchInput = $('#cnn-header .search-input');
			if(!container.hasClass('active')){
				container.addClass('active');
				evt.preventDefault();
			}
			else if(container.hasClass('active') && searchInput.val().length > 1){
				container.removeClass('active');
				$('#cnn-header form').submit();
				// clear and hide result container when we press close
				//container.find('.result-container').fadeOut(100, function(){$(this).empty();});
			}
	});
	$(".search-close").click(function(evt){
			var container = $('#cnn-header .search-wrapper');
			var searchInput = $('#cnn-header .search-input');				
			container.removeClass('active');
			// clear input
			searchInput.val("");
	});
	/* end Function for search option */

});

//function to return last argument of the url
function getLastArgFromPath(argPath){
	var argPathSplit = argPath.split("/");
	var lastArg = argPathSplit.pop();
	return lastArg;
}
//end function to return last argument of the url

//Google Translate
function googleTranslateElementInit() {
	new google.translate.TranslateElement({
			pageLanguage: 'en',
			layout: google.translate.TranslateElement.InlineLayout.SIMPLE,
			includedLanguages: 'en,es,fr,de,zh-Hant',
			multilanguagePage: true
	}, 'google_translate_element');
}
//end Google Translate