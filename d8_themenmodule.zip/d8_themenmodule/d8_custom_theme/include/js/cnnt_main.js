$ = jQuery.noConflict();
(function() {
    'use strict';

    /**
     * Establishing global object here, as this will allow intellisense to work throughout project
     */
    window.CnnTours = window.CnnTours || {};

    CnnTours.methods = CnnTours.methods || {

        IeBugFixBootStrap: function() {
            if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
                var msViewportStyle = document.createElement('style')
                msViewportStyle.appendChild(
                    document.createTextNode(
                        '@-ms-viewport{width:auto!important}'
                    )
                )
                document.querySelector('head').appendChild(msViewportStyle)
            }
        },

        scrollPageTop: function() {
            $(document).ready(function() {
                $(this).scrollTop(0);
            });
        },

        detectMobile: function() {
            var detectmob = false;
            if (navigator.userAgent.match(/Android/i) || navigator.userAgent.match(/webOS/i) || navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/iPod/i) || navigator.userAgent.match(/BlackBerry/i) || navigator.userAgent.match(/Windows Phone/i)) {
                detectmob = true;
            }
            return detectmob;
        },

        windoDimension: function() {
            var winW = $(window).width();

        },

        offCanvasmenu: function() {
            $('#cnn-mainContent').append("<div class='mask'></div>");
            var $el = $('body.nav-offcanvas')

            $(".navbar-toggle, div.mask, .closeMenu, .cnn-menu .page-scroll, .menu-map").click(function() {
                toggleAction();
            });

            $(document).keyup(function(e) {
                if (e.keyCode == 27) {
                    if ($el.hasClass('show-nav')) {
                        toggleAction();
                    }
                }
            });
            $('.cnn-menu > .nav > li a').click(function(e) {
                if ($el.hasClass('show-nav')) {
                    toggleAction();
                }
            });

            function toggleAction() {
                $('.navbar-toggle').toggleClass("active");
                $('.cnn-menu').toggleClass('slideDown');
                $('.page-content').toggleClass('slide-right');
                toggleNav();
            }

            function toggleNav() {

                if ($el.hasClass('show-nav')) {
                    // Do things on Nav Close
                    $el.removeClass('show-nav');
                    toogleAnim();
                } else {
                    // Do things on Nav Open
                    $el.addClass('show-nav');
                    toogleAnim();
                }

            }

            function toogleAnim() {
                setTimeout(function() {
                    $('.cnn-menu').toggleClass('addAnim')

                }, 250);
            }

            $('.scrollable').customScrollbar();

        },

        matchWindowHeight: function(el) {
            var hh = $('#cnn-header > .navbar').height() || 0;
            var fh = $('#cnn-footer').height() || 0;
            var wh = $(window).height();
            var ww = $(window).width();
            var mapH = $('.setMapHeight');
            /*  $(el).css({
                 height: wh
             }); */

            if (mapH.length) {

                if (ww <= 974) {
                    mapH.removeAttr('style');

                } else {

                    mapH.css({
                        height: wh - fh
                    });
                }

            }

        },

        pageScrolling: function() {

            $('a.page-scroll').bind('click', function(event) {
                var $anchor = $(this);
                $('html, body').stop().animate({
                    scrollTop: $($anchor.attr('href')).offset().top
                }, 750, 'easeInOutExpo');
                event.preventDefault();
            });
        },

        dropDownAnimation: function() {
            var dropdownSelectors = $('.dropdown, .dropup');

            // Custom function to read dropdown data
            // =========================
            function dropdownEffectData(target) {
                // @todo - page level global?
                var effectInDefault = null,
                    effectOutDefault = null;
                var dropdown = $(target),
                    dropdownMenu = $('.dropdown-menu', target);
                var parentUl = dropdown.parents('ul.nav');

                // If parent is ul.nav allow global effect settings
                if (parentUl.size() > 0) {
                    effectInDefault = parentUl.data('dropdown-in') || null;
                    effectOutDefault = parentUl.data('dropdown-out') || null;
                }

                return {
                    target: target,
                    dropdown: dropdown,
                    dropdownMenu: dropdownMenu,
                    effectIn: dropdownMenu.data('dropdown-in') || effectInDefault,
                    effectOut: dropdownMenu.data('dropdown-out') || effectOutDefault,
                };
            }

            // Custom function to start effect (in or out)
            // =========================
            function dropdownEffectStart(data, effectToStart) {
                if (effectToStart) {
                    data.dropdown.addClass('dropdown-animating');
                    data.dropdownMenu.addClass('animated');
                    data.dropdownMenu.addClass(effectToStart);
                }
            }

            // Custom function to read when animation is over
            // =========================
            function dropdownEffectEnd(data, callbackFunc) {
                var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
                data.dropdown.one(animationEnd, function() {
                    data.dropdown.removeClass('dropdown-animating');
                    data.dropdownMenu.removeClass('animated');
                    data.dropdownMenu.removeClass(data.effectIn);
                    data.dropdownMenu.removeClass(data.effectOut);

                    // Custom callback option, used to remove open class in out effect
                    if (typeof callbackFunc == 'function') {
                        callbackFunc();
                    }
                });
            }

            dropdownSelectors.on({
                "show.bs.dropdown": function() {
                    // On show, start in effect
                    var dropdown = dropdownEffectData(this);
                    dropdownEffectStart(dropdown, dropdown.effectIn);
                },
                "shown.bs.dropdown": function() {
                    // On shown, remove in effect once complete
                    var dropdown = dropdownEffectData(this);
                    if (dropdown.effectIn && dropdown.effectOut) {
                        dropdownEffectEnd(dropdown, function() {});
                    }
                },
                "hide.bs.dropdown": function(e) {
                    // On hide, start out effect
                    var dropdown = dropdownEffectData(this);
                    if (dropdown.effectOut) {
                        e.preventDefault();
                        dropdownEffectStart(dropdown, dropdown.effectOut);
                        dropdownEffectEnd(dropdown, function() {
                            dropdown.dropdown.removeClass('open');
                        });
                    }
                },
            });
        },

        hideBtnOnScroll: function() {
            $(window).scroll(function() {

                if ($('body').hasClass('onExpand')) {
                    $('body').removeClass('onExpand');

                    $('.cnn-zone').removeClass('expanded');
                }


                $('.callActionBtn').addClass('fadeBtn');
                $("div.menu-horizontal").addClass("fade");

                clearTimeout($.data(this, "scrollCheck"));
                $.data(this, "scrollCheck", setTimeout(function() {
                    $('.callActionBtn').removeClass('fadeBtn');
                    CnnTours.methods.toogleHorizontalMenu();

                }, 250));

            });
        },
					autoScrollToNextSection: function(el) {

            $(el).first().addClass('active');

            $('#cnn-mainWrapper').on('mousewheel DOMMouseScroll', function(e) {
                e.preventDefault();
                var delta = e.originalEvent.detail < 0 || e.originalEvent.wheelDelta > 0 ? 1 : -1;
                var active = $(el + '.active');
                navScroll(delta, active);

            });


            $(document).keydown(function(ev) {
                var delta;
                var active = $(el + '.active');
                if (ev.which == $.ui.keyCode.DOWN) {
                    ev.preventDefault();
                    delta = -1;
                    navScroll(delta, active);

                } else if (ev.which == $.ui.keyCode.UP) {
                    ev.preventDefault();
                    delta = 1;
                    navScroll(delta, active);

                }
            });

            function navScroll(delta, active) {
								$('.menu-horizontal li a.page-scroll').removeClass('active');
                var next, prev;
                if (delta < 0) {

                    next = active.next();

                    var lastChild = $(el).last();

                    if (!lastChild.hasClass('active')) {

                        if (next.length) {
                            var timer = setTimeout(function() {
                                $('body, html').stop().animate({
                                    scrollTop: next.offset().top
                                }, 750, 'easeInOutExpo');
                                next.addClass('active')
                                    .siblings().removeClass('active');
                                clearTimeout(timer);
                            }, 200);
                            var nextID = next.children("section.cnn-zone").attr("id")
                            $("div.menu-list").children(".block-menu").find("a").each(function() {
                                if (($(this).attr("href")) == ("#" + nextID)) {
                                    $(this).closest(".menu-horizontal").find("a.page-scroll").parent().removeClass("active");
                                    $(this).parent().addClass("active");
                                    $(this).closest(".menu-horizontal").find("a.page-scroll").parents('.menu-list').removeClass("active");
                                    $(this).parents('.menu-list').addClass("active");
                                }
                            });

                        }

                    } else {
                        lastChild.addClass('active')
                            .siblings().removeClass('active');

                    }
                } else {
                    prev = active.prev();
                    if (prev.length) {
                        var timer = setTimeout(function() {
                            $('body, html').stop().animate({
                                scrollTop: prev.offset().top
                            }, 750, 'easeInOutExpo');
                            prev.addClass('active')
                                .siblings().removeClass('active');
                            clearTimeout(timer);
                        }, 200);
                        var prevID = prev.children("section.cnn-zone").attr("id")
                        $("div.menu-list").children(".block-menu").find("a").each(function() {
                            if (($(this).attr("href")) == ("#" + prevID)) {
                                $(this).closest(".menu-horizontal").find("a.page-scroll").parent().removeClass("active");
                                $(this).parent().addClass("active");
                                $(this).closest(".menu-horizontal").find("a.page-scroll").parents('.menu-list').removeClass("active");
                                $(this).parents('.menu-list').addClass("active");
                            }
                        });

                    }
                }
            }


            $('a.page-scroll').on('click', function() {

                $(el).removeClass('active');
								$('.menu-horizontal li a.page-scroll').removeClass('active');
                var anchor = $(this).attr('href');
                $(anchor).parent().addClass('active');

                $(this).closest(".menu-horizontal").find("a.page-scroll").parents('.menu-list').removeClass("active");
                $(this).closest(".menu-horizontal").find("a.page-scroll").parent().removeClass("active");
                $("div.menu-list").children(".block-menu").find("a").each(function() {
                    if (($(this).attr("href")) == (anchor)) {
                        $(this).closest(".menu-horizontal").find("a.page-scroll").parent().removeClass("active");
                        $(this).parent().addClass("active");
                        $(this).closest(".menu-horizontal").find("a.page-scroll").parents('.menu-list').removeClass("active");
                        $(this).parents('.menu-list').addClass("active");
                    }
                });

            });

        },

        toogleHorizontalMenu: function() {
            var scrollTop = $(window).scrollTop();
            $('.cnn-zone').each(function() {
                var topDistance = $(this).offset().top;
                var flag = 1;
                if (topDistance === scrollTop) {
                    var attrId = $(this).attr("id");
                    if (!(attrId == 'cnn-store' || attrId == 'host-event' || attrId == 'contact-us')) {
                        $("div.menu-horizontal").removeClass("fade");
                    } else {
                        $("div.menu-horizontal").addClass("fade");
                    }
                    
                          

                }


                function setActiveBlock(attrId) {                
                    $('#menu-horizontal .menu-list li').each(function() {
                        var anch = $(this).find('a').attr("href");
                        var concatId = "#" + attrId
                        if (anch == concatId) {
                            $('#menu-horizontal .sub-menu-list li a[href$= "' + concatId + '"]').addClass('active')
                            $('#menu-horizontal .sub-menu-list li a[href$= "' + concatId + '"]').parents('.menu-list').addClass('active')
                        }
                    });              
                }


            });
        },

        activeSectionToTop: function() {
            var activeSectionoffset = $('.cnn-zone.active').offset().top;
            var body = $("html, body");
            body.scrollTop(activeSectionoffset);

            //body.stop().animate({ scrollTop: activeSectionoffset }, '250', 'swing');

        },

        onScrollInitAnim: function(items, trigger) {
            items.each(function() {
                var cnnElement = $(this),
                    cnnAnimationClass = cnnElement.attr('data-cnn-animation'),
                    cnnAnimationDelay = cnnElement.attr('data-cnn-animation-delay');

                cnnElement.css({
                    '-webkit-animation-delay': cnnAnimationDelay,
                    '-moz-animation-delay': cnnAnimationDelay,
                    'animation-delay': cnnAnimationDelay
                });

                var cnnTrigger = (trigger) ? trigger : cnnElement;

                cnnTrigger.waypoint(function() {

                    cnnElement.addClass('animated').addClass(cnnAnimationClass);
                }, {
                    triggerOnce: true,
                    offset: '90%'
                });
            });
        },

        rippleEffect: function(el) {
            /*jQuery*/


            var ink, d, x, y;
            $(el).mousedown(function(e) {
                    $(this).addClass('hoverShadow');

                    if ($(this).find(".ink").length === 0) {
                        $(this).prepend("<span class='ink'></span>");
                    }

                    ink = $(this).find(".ink");
                    ink.removeClass("animate");

                    if (!ink.height() && !ink.width()) {
                        d = Math.max($(this).outerWidth(), $(this).outerHeight());
                        ink.css({ height: d, width: d });
                    }

                    x = e.pageX - $(this).offset().left - ink.width() / 2;
                    y = e.pageY - $(this).offset().top - ink.height() / 2;

                    ink.css({ top: y + 'px', left: x + 'px' }).addClass("animate");
                })
                .mouseup(function(e) {
                    $(this).removeClass('hoverShadow');
                });

        },

        applyImgBg: function(el) {
            var selector = $('[' + el + ']');
            if (selector.length) {
                selector.each(function() {
                    var _this = $(this)
                    var imageUrl = _this.attr(el);
                    _this.css("background-image", 'url("' + imageUrl + '")');
                });
            }
        },

        weatherWidget: function(obj) {

            init();

            //Initialize all
            function init() {
                getCurrentPositionDone();
            }

            //API data for given geoPosition
            function getCurrentPositionDone() {
                var query = obj.latitude + "," + obj.longitude;
                var apiKey = obj.apiKey;
                var url = "http://api.wunderground.com/api/" + apiKey + "/geolookup/forecast/q/" + query + ".json";
                $.ajax(url, {
                    success: render,
                    error: function() {
                        var data = JSON.parse(localStorage.getItem('offlineData'));
                        render(data, "offline");
                    }
                });
            }

            // api result
            function render(result, m) {
                var mode = m;
                var country = result.location.country;
                var country_name = result.location.country_name;
                var city = result.location.city;
                var state = result.location.state;
                var forecast = result.forecast.simpleforecast.forecastday;
                renderWeather(country, city, state, forecast);

                //API success:: store data in to localStorage
                if (mode == "success") {
                    if (typeof localStorage === "undefined") {
                        console.log("Browser Not Suppoted Local Storage");
                    } else {
                        localStorage.clear();
                        localStorage.setItem("offlineData", JSON.stringify(result));
                    }
                }
            }

            //DOM Manipulation with rendered data
            function renderWeather(country, city, state, forecast) {
                var tempUnit = obj.tempUnit;
                var tempUnitDeg = ((tempUnit == "fahrenheit") ? "°F" : "°C");
                var condition = forecast[0];
                var widgetEl = obj.widgetEl;
                var imageSrc = drupalSettings.path.baseUrl + "sites/default/files/w-icons/" + condition.icon + ".svg";
                var forecastdetail = condition.conditions;
                $(widgetEl).find(".city").text(city);
                $(widgetEl).find(".state").text(state);
                $(widgetEl).find(".farh .maxF").text(condition.high[tempUnit] + tempUnitDeg);
                $(widgetEl).find(".farh .minF").text(condition.low[tempUnit] + tempUnitDeg);
                $(widgetEl).find(".w-icon img").attr({ src: imageSrc });
                $(widgetEl).find(".dropdown-toggle").attr({ title: forecastdetail });

                var todayIndex = 0;
                $.each(forecast, function(index, item) {
                    if (index === todayIndex) return;
                    renderForecast(index, item);
                });
            }


            function renderForecast(index, item) {
                var tempUnit = obj.tempUnit;
                var tempUnitDeg = ((tempUnit == "fahrenheit") ? "°F" : "°C");
                var widgetEl = obj.widgetEl;
                var fList = $(widgetEl).find("ul.dropdown-menu");
                var imageSrc = drupalSettings.path.baseUrl + "sites/default/files/w-icons/" + item.icon + ".svg";
                var forecastdetail = item.conditions;
                var maxF = item.high[tempUnit];
                var minF = item.low[tempUnit];

                var li = $('<li/>')
                    .attr({ title: forecastdetail })
                    .appendTo(fList);
                var fContent = "<div class='col-xs-5 list-day'>" + item.date.weekday + "</div>" +
                    "<div class='col-xs-7 list-farh'>" + "<i class='wi'><img src='" + imageSrc + "' class='img-responsive'/></i>" + maxF + tempUnitDeg + " / " + minF + tempUnitDeg + "</div>";

                var aaa = $('<a/>')
                    .html(fContent)
                    .appendTo(li);

            }
        },

        weatherWidgetMobile: function(obj) {

            init();

            //Initialize all
            function init() {
                getCurrentPositionDone();
            }

            //API data for given geoPosition
            function getCurrentPositionDone() {
                var query = obj.latitude + "," + obj.longitude;
                var apiKey = obj.apiKey;
                var url = "http://api.wunderground.com/api/" + apiKey + "/geolookup/forecast/q/" + query + ".json";
                $.ajax(url, {
                    success: render,
                    error: function() {
                        var data = JSON.parse(localStorage.getItem('offlineData'));
                        render(data, "offline");
                    }
                });
            }

            // api result
            function render(result, m) {
                var mode = m;
                var country = result.location.country;
                var country_name = result.location.country_name;
                var city = result.location.city;
                var state = result.location.state;
                var forecast = result.forecast.simpleforecast.forecastday;
                renderWeather(country, city, state, forecast);

                //API success:: store data in to localStorage
                if (mode == "success") {
                    if (typeof localStorage === "undefined") {
                        console.log("Browser Not Suppoted Local Storage");
                    } else {
                        localStorage.clear();
                        localStorage.setItem("offlineData", JSON.stringify(result));
                    }
                }
            }

            //DOM Manipulation with rendered data
            function renderWeather(country, city, state, forecast) {
                var tempUnit = obj.tempUnit;
                var tempUnitDeg = ((tempUnit == "fahrenheit") ? "°F" : "°C");
                var condition = forecast[0];
                var widgetEl = obj.widgetEl;
								var imageSrc = drupalSettings.path.baseUrl + "sites/default/files/w-icons/" + condition.icon + ".svg";               
							 //var imageSrc = "images/w-icons/" + condition.icon + ".svg";
                var forecastdetail = condition.conditions;
                $(widgetEl).find(".city").text(city);
                $(widgetEl).find(".state").text(state);

                var todayIndex = 0;
                $.each(forecast, function(index, item) {
                    /* if (index === todayIndex) return; */
                    renderForecast(index, item);
                });
            }


            function renderForecast(index, item) {
                var tempUnit = obj.tempUnit;
                var tempUnitDeg = ((tempUnit == "fahrenheit") ? "°F" : "°C");
                var widgetEl = obj.widgetEl;
                var fList = $(widgetEl).find("ul.mobile-view-weather");
                var imageSrc = drupalSettings.path.baseUrl + "sites/default/files/w-icons/" + item.icon + ".svg";
								//var imageSrc = "images/w-icons/" + item.icon + ".svg";
                var forecastdetail = item.conditions;
                var maxF = item.high[tempUnit];
                var minF = item.low[tempUnit];

                var li = $('<li class="each-day-weather"/>')
                    .attr({ title: forecastdetail })
                    .appendTo(fList);
                /*var todayIndex = 0;
                if (index === todayIndex) {
                    item.date.weekday ="Today";
                };*/
                var fContent =
                    "<div class='list-day'>" + item.date.weekday.substring(0, 3) + "</div>" +
                    "<div class='w-icon'>" + "<img src='" + imageSrc + "' class='img-resposive'>" + "</div>" +
                    "<div class='farh small'>" + "<span>" + maxF + tempUnitDeg + "</span>" + "/" + "<span> " + minF + tempUnitDeg + "</span>" + "</div>";
                var aaa = $('<div class="day-weather">')
                    .html(fContent)
                    .appendTo(li);

            }
        },


        googleMapApi: function(el) {
            if (typeof el !== 'undefined' || el !== null) {
                var map_canvas = document.getElementById(el);
                var center = new google.maps.LatLng(33.757916, -84.394776)
                var zoom = 16

                var map_options = {
                    center: center,
                    zoom: zoom,
                    mapTypeId: google.maps.MapTypeId.ROADMAP,
                    scrollwheel: true,
                    zoomControl: true,
                    scaleControl: false
                };

                var map = new google.maps.Map(map_canvas, map_options);

                var marker = new google.maps.Marker({
                    position: center,
                    map: map,
                    title: 'CNN Studio Tours'
                });

                var getMarkerPos = marker.getPosition();

                function resetPos() {
                    map.setZoom(zoom);
                    map.setCenter(getMarkerPos);
                }

                marker.addListener('click', function() {
                    resetPos();
                });

                google.maps.event.addListener(map, 'bounds_changed', function() {
                    $('.reset-map').stop().fadeOut();
                    var isPonterinView = map.getBounds().contains(marker.getPosition());
                    if (isPonterinView === false) {
                        $('.reset-map').stop().fadeIn();
                    }

                });

                $('.reset-map').click(function(event) {
                    resetPos();
                });

            }

        },

        cnnMenuLeftPos: function() {
            var winW = $(window).width();
            var getNavBrandPos = $('.navbar-brand').offset().left;

            if (winW >= 1130) {

                $('.cnn-menu').css("left", getNavBrandPos)
            } else {
                $('.cnn-menu').removeAttr('style');
            }
        },

        searchToggle: function() {

            $('.search-icon, .search-close').click(function(evt) {
                var obj = $(this);
                var container = $(obj).closest('.search-wrapper');
                if (!container.hasClass('active')) {
                    container.addClass('active');
                    evt.preventDefault();
                } else if (container.hasClass('active') && $(obj).closest('.input-holder').length == 0) {
                    container.removeClass('active');
                    // clear input
                    container.find('.search-input').val('');
                    // clear and hide result container when we press close
                    container.find('.result-container').fadeOut(100, function() { $(this).empty(); });
                }

            });

        },

        mapWrapperWidth: function() {
            var winW = $(window).width();
            var pos = $('.map-wrapper').offset().left
            var setMapWrapperWidth = (winW - pos) - 15
            if (winW >= 1130) {
                $('#googleMap').width(setMapWrapperWidth);
            } else {
                $('#googleMap').width(setMapWrapperWidth + 15);
            }
        },

        adaptiveSectionImg: function(el) {
            var $selector = $(el);
            if ($selector.length) {
                $selector.find('img').css('display', 'none');
                setResponiveBg();
            }

            function deviceMode(bp) {
                var _device = "m";
                var winWidth = $(window).width();
                if (winWidth > bp) {
                    _device = "d";
                }
                return _device;
            }

            function setResponiveBg() {
                var mode = deviceMode(540); // Breakpoint as Input Value | return "m" / "d"  | defult value "m"
                $selector.each(function() {
                    var _this = $(this);
                    var desktopImg = _this.find('img').attr('src');
                    var mobileImg = _this.find('img').data("mobilesrc");

                    if (typeof mobileImg !== 'undefined') {
                        _this.css("background-image", 'url("' + desktopImg + '")');
                        if (mode !== "d") {
                            _this.css("background-image", 'url("' + mobileImg + '")');
                        }
                    }

                    if (typeof mobileImg == 'undefined' || mobileImg == '') {
                        _this.css("background-image", 'url("' + desktopImg + '")');
                    }


                });

            }

        },


        datePickerBlock: function() {
            var dateMin = new Date();
            var weekDays = AddWeekDays(0);


            dateMin.setDate(dateMin.getDate() + weekDays);

            var natDays = [
                [1, 1, 'usa'],
                [12, 25, 'usa'],
                [12, 26, 'usa']
            ];

            function noWeekendsOrHolidays(date) {
                return nationalDays(date);

                /* var noWeekend = $.datepicker.noWeekends(date);                

                 if (noWeekend[0]) {
                     return nationalDays(date);
                 } else {
                     return noWeekend;
                 }*/
            }

            function nationalDays(date) {
                for (var i = 0; i < natDays.length; i++) {
                    if (date.getMonth() == natDays[i][0] - 1 && date.getDate() == natDays[i][1]) {
                        return [false, natDays[i][2] + '_day'];
                    }
                }
                return [true, ''];
            }

            function AddWeekDays(weekDaysToAdd) {
                var daysToAdd = 0
                var mydate = new Date()
                var day = mydate.getDay()
                weekDaysToAdd = weekDaysToAdd - (5 - day)
                if ((5 - day) < weekDaysToAdd || weekDaysToAdd == 1) {
                    daysToAdd = (5 - day) + 2 + daysToAdd
                } else { // (5-day) >= weekDaysToAdd
                    daysToAdd = (5 - day) + daysToAdd
                }
                while (weekDaysToAdd != 0) {
                    var week = weekDaysToAdd - 5
                    if (week > 0) {
                        daysToAdd = 7 + daysToAdd
                        weekDaysToAdd = weekDaysToAdd - 5
                    } else { // week < 0
                        daysToAdd = (5 + week) + daysToAdd
                        weekDaysToAdd = weekDaysToAdd - (5 + week)
                    }
                }

                return daysToAdd;
            }

            $('#datepicker').datepicker({
                inline: true,
                beforeShowDay: noWeekendsOrHolidays,
                altField: '#txtCollectionDate',
                showOn: "both",
                dateFormat: "mm/dd/yy",
                minDate: dateMin,
                onSelect: function(dateText, inst) {
                    var date = $(this).val();
                    $('.selected-date').html("<small>Date Selected</small>" + date);
                    $('.sel-date').html(date);
                    revokeButton('.btn-nxt-time')
                }
            });


            $('.slot-holder .cnt>ul>li').on('click', function() {
                revokeButton('.btn-nxt-visitor')

                var time = $(this).find('input').val();
                $('.selected-time').html("<small>Time Selected</small>" + time);
                $('.sel-time').html(time);

            });
            dateCarouselNav();

            $('#purchaseTicket').on('shown.bs.modal', function() {
                $('.btn-grey').click(function(e) {
                    return false;
                });


            });

            function revokeButton(el) {
                $(el).removeAttr("disabled");
                $(el).unbind('click');
                $(el).addClass('active');
            }

            inputValidate();
            confirmTickets();

            function inputValidate() {
                $(".visitor-count input.form-control").on("keypress keyup blur paste", function(event) {

                    var that = this;
                    //paste event 
                    if (event.type === "paste") {
                        setTimeout(function() {
                            $(that).val($(that).val().replace(/[^\d].+/, ""));
                        }, 100);
                    } else {

                        if (event.which < 48 || event.which > 57) {
                            event.preventDefault();
                        } else {
                            $(this).val($(this).val().replace(/[^\d].+/, ""));
                        }
                    }

                    if (event.type === "blur") {
                        var adultCount = parseInt($("input[name='adult']").val() || 0);
                        var seniorCount = parseInt($("input[name='senior']").val() || 0);
                        var studentCount = parseInt($("input[name='student']").val() || 0);
                        var childCount = parseInt($("input[name='child']").val() || 0);
                        var totalVisitors = adultCount + seniorCount + studentCount + childCount;
                        var standardTicketPrice = CnnTours.methods.standardTicketPrice();
                        var totalPrice = calculateTicketTotal(standardTicketPrice, adultCount, seniorCount, studentCount, childCount);

                        $('.total-visitors').html(totalVisitors);
                        $('.total-price').html(totalPrice);
                        $('.adult-count').html(adultCount);
                        $('.senior-count').html(seniorCount);
                        $('.student-count').html(studentCount);
                        $('.child-count').html(childCount);
                    }


                    if ($("input[name='adult']").val() || $("input[name='senior']").val() || $("input[name='student']").val() || $("input[name='child']").val()) {
                        $('.total-tickets').css("display", "inline-block");
                        revokeButton('.btn-nxt-confirm');
                    } else {
                        $('.total-tickets').css("display", "none");
                        $('.btn-nxt-confirm').removeClass('active');
                        $('.btn-nxt-confirm').attr('disabled', 'disabled');
                        $('.btn-nxt-confirm').click(function(e) {
                            return false;
                        });

                    }

                });
            }

            function confirmTickets() {
                var price = CnnTours.methods.standardTicketPrice();
                $('.adult-price').html("$" + price.adult + " x ");
                $('.senior-price').html("$" + price.senior + " x ");
                $('.student-price').html("$" + price.student + " x ");
                $('.child-price').html("$" + price.child + " x ");
            }

            function calculateTicketTotal(price, adultCount, seniorCount, studentCount, childCount) {
                return (price.adult * adultCount) + (price.senior * seniorCount) + (price.student * studentCount) + (price.child * childCount)
            }


            function dateCarouselNav() {
                var clickEvent = false;

                $('#ticketCarousel').on('click', '.nav a', function() {
                    clickEvent = true;
                    $('.nav li').removeClass('active');
                    $(this).parent().addClass('active');
                }).on('slid.bs.carousel', function(e) {
                    if (!clickEvent) {
                        var count = $('.nav').children().length - 1;
                        var current = $('.nav li.active');
                        current.removeClass('active').next().addClass('active');
                        var id = parseInt(current.data('slide-to'));
                        if (count == id) {
                            $('.nav li').first().addClass('active');
                        }
                    }

                    clickEvent = false;
                });
            }

            function ConvertFormToJSON(form) {

                var formData = {
                    'adult': adultCount,
                    'senior': seniorCount,
                    'student': studentCount,
                    'child': childCount
                };

            }


        },
        standardTicketPrice: function() {
            return {
                adult: 13,
                senior: 15,
                student: 15,
                child: 13
            }
        },

        accordianMenu: function() {

            if ($('#cnnAccordianMenu').length) {

                $('.menu-list a.page-scroll').on('click', function() {

                    $('#cnnAccordianMenu >li>ul').hide();
                    $('#cnnAccordianMenu li .iconHolder').removeClass('active');
                });


                $('#cnnAccordianMenu >li>ul').hide();
                $('#cnnAccordianMenu li > span.iconHolder').click(
                    function() {

                        var checkElement = $(this).next();
                        if ((checkElement.is('ul')) && (checkElement.is(':visible'))) {

                            return false;
                        }
                        if ((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
                            $('#cnnAccordianMenu ul:visible').slideUp('normal');
                            checkElement.slideDown('normal');
                            $('#cnnAccordianMenu li .iconHolder').removeClass('active');
                            $(this).addClass('active');

                            return false;
                        }
                    }
                );

            }

        },

        menuHorizontalListOnActive: function() {

            $('.menu-horizontal .menu-list li a').click(function() {
                $('.menu-horizontal .menu-list').removeClass('active');
                $(this).parents('.menu-list').addClass('active');
            });
        },

        faqQestionAnswer: function() {
				    $("div.questionAnswer").find("span.plus-minus-icon").each(function(i) {
							 if ( i === 0 ) {
								 $(this).addClass('glyphicon-minus');
								 $(this).closest(".questionAnswer").find("div.faqAnswer:first").addClass("in");
							 }
							 else{
								 $(this).addClass('glyphicon-plus');
							 }
						});
            var selectIds = $('.faqAnswer');
            $(function($) {
                selectIds.on('show.bs.collapse hidden.bs.collapse', function() {
                    $(this).prev().find('.glyphicon').toggleClass('glyphicon-plus glyphicon-minus');
                })
            });
        },

        expandFaq: function() {
            $('.icon.full-screen, .allFaq').click(function() {
                var text = $('.allFaq').text() == 'Show All' ? 'Show Less' : 'Show All';
                $('body').toggleClass('onExpand');
                $(this).parents('.cnn-zone').toggleClass('expanded');
                $('.icon.full-screen').find('.fa').toggleClass('fa-expand');
                $('.icon.full-screen').find('.fa').toggleClass('fa-compress');
                $('.menu-horizontal').toggleClass('fade');
                $('.allFaq').text(text);
            })
        },

        scrollableContentHeight: function() {
            if ($(window).width() <= 1129) {
                var winHeight = $(window).height();
                var scrollableHeight = winHeight - 250;
                $('.cnn-boxyCont .scrollable').css("max-height", scrollableHeight)
            } else {
                $('.cnn-boxyCont .scrollable').removeAttr('style');
            }
        }

    }

    /**
     * run on document load
     */
    $(function() {

        CnnTours.methods.accordianMenu();
        CnnTours.methods.IeBugFixBootStrap();
        CnnTours.methods.scrollPageTop();
        CnnTours.methods.detectMobile();
        CnnTours.methods.offCanvasmenu();
        CnnTours.methods.dropDownAnimation();
        CnnTours.methods.pageScrolling();
        CnnTours.methods.hideBtnOnScroll();
        CnnTours.methods.autoScrollToNextSection('.view-banner .views-row');
        CnnTours.methods.toogleHorizontalMenu();
        CnnTours.methods.rippleEffect('.ripplelink');
        CnnTours.methods.searchToggle();
        CnnTours.methods.menuHorizontalListOnActive();
        CnnTours.methods.faqQestionAnswer();
        CnnTours.methods.datePickerBlock();
        CnnTours.methods.weatherWidget({
            widgetEl: "#weather-widget",
            apiKey: "69c164663f19b7c5",
            latitude: 33.757916,
            longitude: -84.394776,
            tempUnit: "fahrenheit" // "celsius" | "fahrenheit"
        });
        CnnTours.methods.weatherWidgetMobile({
            widgetEl: "#weather-mobile",
            apiKey: "69c164663f19b7c5",
            latitude: 33.757916,
            longitude: -84.394776,
            tempUnit: "fahrenheit" // "celsius" | "fahrenheit"
        });
        CnnTours.methods.adaptiveSectionImg('.cnnSectionBg');
        CnnTours.methods.expandFaq();

        /**
         * on resize
         */
        $(window).resize(function() {
            clearTimeout(window.resizedFinished);
            window.resizedFinished = setTimeout(function() {
                CnnTours.methods.cnnMenuLeftPos();
								if($('#contact-us').length!==0){
									CnnTours.methods.mapWrapperWidth();
								}	
                CnnTours.methods.matchWindowHeight('.setWinHeight');
                CnnTours.methods.scrollableContentHeight();
               //CnnTours.methods.activeSectionToTop();
                if($('#googleMap').length!==0){
									CnnTours.methods.googleMapApi('googleMap');
								}	
            }, 450);
        }).trigger('resize');

    });

})();
