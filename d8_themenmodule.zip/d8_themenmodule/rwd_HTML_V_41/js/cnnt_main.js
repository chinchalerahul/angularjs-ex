(function() {
    'use strict';

    /**
     * Establishing global object here, as this will allow intellisense to work throughout project
     */
    window.CnnTours = window.CnnTours || {};

    CnnTours.methods = CnnTours.methods || {
        IeBugFixBootStrap: function() {
            if (navigator.userAgent.match(/IEMobile\/10\.0/)) {
                var msViewportStyle = document.createElement('style')
                msViewportStyle.appendChild(
                    document.createTextNode(
                        '@-ms-viewport{width:auto!important}'
                    )
                )
                document.querySelector('head').appendChild(msViewportStyle)
            }
        },

        lazyload: function() {
            // Example
            var bLazy = new Blazy({
                breakpoints: [{
                    width: 420 // max-width
                        ,
                    src: 'data-src-small'
                }]
            });
        },

        mobilecheck: function() {
            var check = false;
            (function(a) {
                if (/(android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|mobile.+firefox|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows ce|xda|xiino/i.test(a) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0, 4))) check = true;
            })(navigator.userAgent || navigator.vendor || window.opera);
            return check;
        },

        hiddenBodyScroll: function() {

            var isMobile = CnnTours.methods.mobilecheck();

            if (isMobile == false) {
                $('body').css("overflow", "hidden");
            } else {
                $('body').css("overflow", "auto");
            }

        },

        scrollPageTop: function() {
            $(document).ready(function() {
                $(this).scrollTop(0);
            });
        },

        detectMobile: function() {
            var detectmob = false;
            if (navigator.userAgent.match(/Android/i) || navigator.userAgent.match(/webOS/i) || navigator.userAgent.match(/iPhone/i) || navigator.userAgent.match(/iPad/i) || navigator.userAgent.match(/iPod/i) || navigator.userAgent.match(/BlackBerry/i) || navigator.userAgent.match(/Windows Phone/i)) {
                detectmob = true;
            }
            return detectmob;
        },

        windoDimension: function() {
            var winW = $(window).width();

        },

        offCanvasmenu: function() {
            $('#cnn-mainContent').append("<div class='mask'></div>");
            var $el = $('body.nav-offcanvas')

            $(".navbar-toggle, div.mask, .closeMenu, .cnn-menu a").click(function() {

                toggleAction();
            });

            $(document).keyup(function(e) {
                if (e.keyCode == 27) {
                    if ($el.hasClass('show-nav')) {
                        toggleAction();
                    }
                }
            });
            $('.cnn-menu > .nav > li a').click(function(e) {
                if ($el.hasClass('show-nav')) {
                    toggleAction();
                }
            });

            function toggleAction() {
                $('.navbar-toggle').toggleClass("active");
                $('.cnn-menu').toggleClass('slideDown');
                $('.page-content, #directionsAndParking .container-page-content > .row').toggleClass('slide-right');
                toggleNav();
            }

            function toggleNav() {

                if ($el.hasClass('show-nav')) {
                    // Do things on Nav Close
                    $el.removeClass('show-nav');
                    toogleAnim();
                } else {
                    // Do things on Nav Open
                    $el.addClass('show-nav');
                    toogleAnim();
                }

            }

            function toogleAnim() {
                setTimeout(function() {
                    $('.cnn-menu').toggleClass('addAnim')

                }, 250);
            }

            $('.scrollable').customScrollbar();

        },

        matchWindowHeight: function(el) {
            var hh = $('#cnn-header > .navbar').height() || 0;
            var fh = $('#cnn-footer').height() || 0;
            var wh = $(window).height();
            var ww = $(window).width();
            var mapH = $('.setMapHeight');
            var isVHsupport = cssPropertyValueSupported('width', '1vh');

            function cssPropertyValueSupported(prop, value) {
                var d = document.createElement('div');
                d.style[prop] = value;
                return d.style[prop] === value;
            }

            if (isVHsupport == false) {
                $(el).css({
                    height: wh
                });
            }

            /*  $(el).css({
                 height: wh
             }); */

            if (mapH.length) {

                if (ww <= 974) {
                    mapH.removeAttr('style');

                } else {

                    mapH.css({
                        height: wh - fh
                    });
                }

            }

        },

        pageScrolling: function() {
            $.localScroll({
                target: '.loaclscroll', // could be a selector or a jQuery object too.
                queue: true,
                duration: 600,
                hash: false
            });

        },

        autoScrollToNextSection: function(el) {
            $(el).first().addClass('active');
            $('#cnn-mainWrapper').on('mousewheel DOMMouseScroll', function(e) {
                e.preventDefault();
                var delta = e.originalEvent.detail < 0 || e.originalEvent.wheelDelta > 0 ? 1 : -1;
                var active = $(el + '.active');
                navScroll(delta, active);
            });

            $(document).keydown(function(ev) {
                if (ev.keyCode == 32) {
                    return false;
                }

                var delta;
                var active = $(el + '.active');
                if (ev.which == $.ui.keyCode.DOWN) {
                    ev.preventDefault();
                    delta = -1;
                    navScroll(delta, active);

                } else if (ev.which == $.ui.keyCode.UP) {
                    ev.preventDefault();
                    delta = 1;
                    navScroll(delta, active);
                }
            });

            function navScroll(delta, active) {
                var next, prev;
                if (delta < 0) {
                    next = active.next();
                    var lastChild = $(el).last();
                    var isScrollZone = active.next().hasClass('cnn-zone');
                    if ((!lastChild.hasClass('active')) && isScrollZone) {
                        if (next.length) {
                            var timer = setTimeout(function() {
                                $('body, html').stop().animate({
                                    scrollTop: next.offset().top
                                }, 600);
                                next.addClass('active')
                                    .siblings().removeClass('active');
                                clearTimeout(timer);
                            }, 200);
                        }

                    } else {
                        lastChild.addClass('active')
                            .siblings().removeClass('active');

                        var footer = $('#cnn-footer');
                        $('body, html').stop().animate({
                            scrollTop: footer.offset().top
                        }, 600);
                    }

                } else {
                    prev = active.prev();
                    if (prev.length) {
                        var timer = setTimeout(function() {
                            $('body, html').stop().animate({
                                scrollTop: prev.offset().top
                            }, 600);
                            prev.addClass('active')
                                .siblings().removeClass('active');
                            clearTimeout(timer);
                        }, 200);
                    }
                }
            }

            $('a.page-scroll').on('click', function() {
                $(el).removeClass('active');
                var anchor = $(this).attr('href');
                $(anchor).addClass('active');
            });

        },


        dropDownAnimation: function() {
            var dropdownSelectors = $('.dropdown, .dropup');

            // Custom function to read dropdown data
            // =========================
            function dropdownEffectData(target) {
                // @todo - page level global?
                var effectInDefault = null,
                    effectOutDefault = null;
                var dropdown = $(target),
                    dropdownMenu = $('.dropdown-menu', target);
                var parentUl = dropdown.parents('ul.nav');

                // If parent is ul.nav allow global effect settings
                if (parentUl.size() > 0) {
                    effectInDefault = parentUl.data('dropdown-in') || null;
                    effectOutDefault = parentUl.data('dropdown-out') || null;
                }

                return {
                    target: target,
                    dropdown: dropdown,
                    dropdownMenu: dropdownMenu,
                    effectIn: dropdownMenu.data('dropdown-in') || effectInDefault,
                    effectOut: dropdownMenu.data('dropdown-out') || effectOutDefault,
                };
            }

            // Custom function to start effect (in or out)
            // =========================
            function dropdownEffectStart(data, effectToStart) {
                if (effectToStart) {
                    data.dropdown.addClass('dropdown-animating');
                    data.dropdownMenu.addClass('animated');
                    data.dropdownMenu.addClass(effectToStart);
                }
            }

            // Custom function to read when animation is over
            // =========================
            function dropdownEffectEnd(data, callbackFunc) {
                var animationEnd = 'webkitAnimationEnd mozAnimationEnd MSAnimationEnd oanimationend animationend';
                data.dropdown.one(animationEnd, function() {
                    data.dropdown.removeClass('dropdown-animating');
                    data.dropdownMenu.removeClass('animated');
                    data.dropdownMenu.removeClass(data.effectIn);
                    data.dropdownMenu.removeClass(data.effectOut);

                    // Custom callback option, used to remove open class in out effect
                    if (typeof callbackFunc == 'function') {
                        callbackFunc();
                    }
                });
            }

            dropdownSelectors.on({
                "show.bs.dropdown": function() {
                    // On show, start in effect
                    var dropdown = dropdownEffectData(this);
                    dropdownEffectStart(dropdown, dropdown.effectIn);
                },
                "shown.bs.dropdown": function() {
                    // On shown, remove in effect once complete
                    var dropdown = dropdownEffectData(this);
                    if (dropdown.effectIn && dropdown.effectOut) {
                        dropdownEffectEnd(dropdown, function() {});
                    }
                },
                "hide.bs.dropdown": function(e) {
                    // On hide, start out effect
                    var dropdown = dropdownEffectData(this);
                    if (dropdown.effectOut) {
                        e.preventDefault();
                        dropdownEffectStart(dropdown, dropdown.effectOut);
                        dropdownEffectEnd(dropdown, function() {
                            dropdown.dropdown.removeClass('open');
                        });
                    }
                },
            });
        },

        hideBtnOnScroll: function() {
            $(window).scroll(function() {
                if ($('body').hasClass('onExpand')) {
                    $('body').removeClass('onExpand');
                    $('.cnn-zone').removeClass('expanded');
                }


                $('.callActionBtn').addClass('fadeBtn');
                $("div.menu-horizontal").addClass("fade");
                if ($('.icon.full-screen').find('.fa').hasClass('fa-compress')) {

                    $('.icon.full-screen').find('.fa').removeClass('fa-compress');
                    $('.icon.full-screen').find('.fa').addClass('fa-expand');

                    $('.btn-show').text(function(i, text) {
                        return text === "Show More" ? "Show Less" : "Show More";
                    });
                }

                $("div.menu-horizontal").removeClass("flagged");

                clearTimeout($.data(this, "scrollCheck"));
                $.data(this, "scrollCheck", setTimeout(function() {
                    $('.callActionBtn').removeClass('fadeBtn');
                    CnnTours.methods.toogleHorizontalMenu();
                    CnnTours.methods.menuHorizontalListOnActive();

                }, 250));

            });
        },


        toogleHorizontalMenu: function() {
            var scrollTop = $(window).scrollTop();
            $('.cnn-zone').each(function() {
                var topDistance = $(this).offset().top;
                var flag = 1;
                if (topDistance === scrollTop) {
                    var showHmenu = $(this).data("horizontalmenu");
                    if (showHmenu === 'hide') {
                        $("div.menu-horizontal").addClass("fade");

                    } else {
                        $("div.menu-horizontal").removeClass("fade");
                    }


                }


                function setActiveBlock(attrId) {
                    $('#menu-horizontal .menu-list li').each(function() {
                        var anch = $(this).find('a').attr("href");
                        var concatId = "#" + attrId
                        if (anch == concatId) {
                            $('#menu-horizontal .sub-menu-list li a[href$= "' + concatId + '"]').addClass('active')
                            $('#menu-horizontal .sub-menu-list li a[href$= "' + concatId + '"]').parents('.menu-list').addClass('active')
                        }
                    });
                }


            });
        },

        activeSectionToTop: function() {
            bringSectiontoTop();

            var activeSectionoffset = $('.cnn-zone.active').offset().top;
            var body = $("html, body");
            body.scrollTop(activeSectionoffset);

            //body.stop().animate({ scrollTop: activeSectionoffset }, '250', 'swing');


            function bringSectiontoTop() {
                var url = window.location.href;

                if (url.indexOf('#') < 0) {
                    window.location.replace(url + "#");
                } else {
                    window.location.replace(url);
                }
            }

        },

        onScrollInitAnim: function(items, trigger) {
            items.each(function() {
                var cnnElement = $(this),
                    cnnAnimationClass = cnnElement.attr('data-cnn-animation'),
                    cnnAnimationDelay = cnnElement.attr('data-cnn-animation-delay');

                cnnElement.css({
                    '-webkit-animation-delay': cnnAnimationDelay,
                    '-moz-animation-delay': cnnAnimationDelay,
                    'animation-delay': cnnAnimationDelay
                });

                var cnnTrigger = (trigger) ? trigger : cnnElement;

                cnnTrigger.waypoint(function() {

                    cnnElement.addClass('animated').addClass(cnnAnimationClass);
                }, {
                    triggerOnce: true,
                    offset: '90%'
                });
            });
        },

        rippleEffect: function(el) {

            var is_firefox = navigator.userAgent.indexOf('Firefox') > -1;
            if (is_firefox == true) {
                return false;
            } else {
                var ink, d, x, y;
                $(el).mousedown(function(e) {
                        $(this).addClass('hoverShadow');

                        if ($(this).find(".ink").length === 0) {
                            $(this).prepend("<span class='ink'></span>");
                        }

                        ink = $(this).find(".ink");
                        ink.removeClass("animate");

                        if (!ink.height() && !ink.width()) {
                            d = Math.max($(this).outerWidth(), $(this).outerHeight());
                            ink.css({ height: d, width: d });
                        }

                        x = e.pageX - $(this).offset().left - ink.width() / 2;
                        y = e.pageY - $(this).offset().top - ink.height() / 2;

                        ink.css({ top: y + 'px', left: x + 'px' }).addClass("animate");
                    })
                    .mouseup(function(e) {
                        $(this).removeClass('hoverShadow');
                    });
            }

        },

        applyImgBg: function(el) {
            var selector = $('[' + el + ']');
            if (selector.length) {
                selector.each(function() {
                    var _this = $(this)
                    var imageUrl = _this.attr(el);
                    _this.css("background-image", 'url("' + imageUrl + '")');
                });
            }
        },

        weatherWidget: function(obj) {

            init();

            //Initialize all
            function init() {
                getCurrentPositionDone();
            }

            //API data for given geoPosition
            function getCurrentPositionDone() {
                var query = obj.latitude + "," + obj.longitude;
                var apiKey = obj.apiKey;
                var url = "http://api.wunderground.com/api/" + apiKey + "/geolookup/forecast/q/" + query + ".json";
                $.ajax(url, {
                    success: render,
                    error: function() {
                        var data = JSON.parse(localStorage.getItem('offlineData'));
                        render(data, "offline");
                    }
                });
            }

            // api result
            function render(result, m) {
                var mode = m;
                var country = result.location.country;
                var country_name = result.location.country_name;
                var city = result.location.city;
                var state = result.location.state;
                var forecast = result.forecast.simpleforecast.forecastday;
                renderWeather(country, city, state, forecast);

                //API success:: store data in to localStorage
                if (mode == "success") {
                    if (typeof localStorage === "undefined") {
                        console.log("Browser Not Suppoted Local Storage");
                    } else {
                        localStorage.clear();
                        localStorage.setItem("offlineData", JSON.stringify(result));
                    }
                }
            }

            //DOM Manipulation with rendered data
            function renderWeather(country, city, state, forecast) {
                var tempUnit = obj.tempUnit;
                var tempUnitDeg = ((tempUnit == "fahrenheit") ? "°F" : "°C");
                var condition = forecast[0];
                var widgetEl = obj.widgetEl;
                var imageSrc = "images/w-icons/" + condition.icon + ".svg";
                var forecastdetail = condition.conditions;
                $(widgetEl).find(".city").text(city);
                $(widgetEl).find(".state").text(state);
                $(widgetEl).find(".farh .maxF").text(condition.high[tempUnit] + tempUnitDeg);
                $(widgetEl).find(".farh .minF").text(condition.low[tempUnit] + tempUnitDeg);
                $(widgetEl).find(".w-icon img").attr({ src: imageSrc });
                $(widgetEl).find(".dropdown-toggle").attr({ title: forecastdetail });

                var todayIndex = 0;
                $.each(forecast, function(index, item) {
                    if (index === todayIndex) return;
                    renderForecast(index, item);
                });
            }


            function renderForecast(index, item) {
                var tempUnit = obj.tempUnit;
                var tempUnitDeg = ((tempUnit == "fahrenheit") ? "°F" : "°C");
                var widgetEl = obj.widgetEl;
                var fList = $(widgetEl).find("ul.dropdown-menu");
                var imageSrc = "images/w-icons/" + item.icon + ".svg";
                var forecastdetail = item.conditions;
                var maxF = item.high[tempUnit];
                var minF = item.low[tempUnit];

                var li = $('<li/>')
                    .attr({ title: forecastdetail })
                    .appendTo(fList);
                var fContent = "<div class='col-xs-5 list-day'>" + item.date.weekday + "</div>" +
                    "<div class='col-xs-7 list-farh'>" + "<i class='wi'><img src='" + imageSrc + "' class='img-responsive'/></i>" + maxF + tempUnitDeg + " / " + minF + tempUnitDeg + "</div>";

                var aaa = $('<a/>')
                    .html(fContent)
                    .appendTo(li);

            }
        },

        weatherWidgetMobile: function(obj) {

            init();

            //Initialize all
            function init() {
                getCurrentPositionDone();
            }

            //API data for given geoPosition
            function getCurrentPositionDone() {
                var query = obj.latitude + "," + obj.longitude;
                var apiKey = obj.apiKey;
                var url = "http://api.wunderground.com/api/" + apiKey + "/geolookup/forecast/q/" + query + ".json";
                $.ajax(url, {
                    success: render,
                    error: function() {
                        var data = JSON.parse(localStorage.getItem('offlineData'));
                        render(data, "offline");
                    }
                });
            }

            // api result
            function render(result, m) {
                var mode = m;
                var country = result.location.country;
                var country_name = result.location.country_name;
                var city = result.location.city;
                var state = result.location.state;
                var forecast = result.forecast.simpleforecast.forecastday;
                renderWeather(country, city, state, forecast);

                //API success:: store data in to localStorage
                if (mode == "success") {
                    if (typeof localStorage === "undefined") {
                        console.log("Browser Not Suppoted Local Storage");
                    } else {
                        localStorage.clear();
                        localStorage.setItem("offlineData", JSON.stringify(result));
                    }
                }
            }

            //DOM Manipulation with rendered data
            function renderWeather(country, city, state, forecast) {
                var tempUnit = obj.tempUnit;
                var tempUnitDeg = ((tempUnit == "fahrenheit") ? "°F" : "°C");
                var condition = forecast[0];
                var widgetEl = obj.widgetEl;
                var imageSrc = "images/w-icons/" + condition.icon + ".svg";
                var forecastdetail = condition.conditions;
                $(widgetEl).find(".city").text(city);
                $(widgetEl).find(".state").text(state);

                var todayIndex = 0;
                $.each(forecast, function(index, item) {
                    /* if (index === todayIndex) return; */
                    renderForecast(index, item);
                });
            }


            function renderForecast(index, item) {
                var tempUnit = obj.tempUnit;
                var tempUnitDeg = ((tempUnit == "fahrenheit") ? "°F" : "°C");
                var widgetEl = obj.widgetEl;
                var fList = $(widgetEl).find("ul.mobile-view-weather");
                var imageSrc = "images/w-icons/" + item.icon + ".svg";
                var forecastdetail = item.conditions;
                var maxF = item.high[tempUnit];
                var minF = item.low[tempUnit];

                var li = $('<li class="each-day-weather"/>')
                    .attr({ title: forecastdetail })
                    .appendTo(fList);
                /*var todayIndex = 0;
                if (index === todayIndex) {
                    item.date.weekday ="Today";
                };*/
                var fContent =
                    "<div class='list-day'>" + item.date.weekday.substring(0, 3) + "</div>" +
                    "<div class='w-icon'>" + "<img src='" + imageSrc + "' class='img-resposive'>" + "</div>" +
                    "<div class='farh small'>" + "<span>" + maxF + tempUnitDeg + "</span>" + "/" + "<span> " + minF + tempUnitDeg + "</span>" + "</div>";
                var aaa = $('<div class="day-weather">')
                    .html(fContent)
                    .appendTo(li);

            }
        },

        cnnMenuLeftPos: function() {
            var winW = $(window).width();
            var getNavBrandPos = $('.navbar-brand').offset().left;

            if (winW >= 1130) {

                $('.cnn-menu').css("left", getNavBrandPos)
            } else {
                $('.cnn-menu').removeAttr('style');
            }
        },

        searchToggle: function() {

            $('.search-icon, .search-close').click(function(evt) {
                var obj = $(this);
                var container = $(obj).closest('.search-wrapper');
                if (!container.hasClass('active')) {
                    container.addClass('active');
                    evt.preventDefault();
                } else if (container.hasClass('active') && $(obj).closest('.input-holder').length == 0) {
                    container.removeClass('active');
                    // clear input
                    container.find('.search-input').val('');
                    // clear and hide result container when we press close
                    container.find('.result-container').fadeOut(100, function() { $(this).empty(); });
                }

            });

        },

        searchSecondary: function() {

            $('.search-icon').click(function() {
                $(this).parents('search-wrapper').addClass('active');
                $('#cnn-header').addClass('search-expanded');
            });

            $('.search-close').click(function() {
                $('.search-wrapper').removeClass('active');
                $('#cnn-header').removeClass('search-expanded');
            });

            $('html').click(function(e) {
                //if clicked element is not your element and parents aren't your div
                if (e.target.id != '.input-holder' && $(e.target).parents('.search-wrapper').length == 0) {

                    $('.search-wrapper').removeClass('active');
                    $('#cnn-header').removeClass('search-expanded');
                }
            });

        },

        mapWrapperWidth: function() {
            var winW = $(window).width();
            var pos = $('.map-wrapper').offset().left
            var setMapWrapperWidth = (winW - pos) - 15
            if (winW >= 1130) {
                //$('#googleMap').width(setMapWrapperWidth);
            } else {
                // $('#googleMap').width(setMapWrapperWidth + 15);
            }
        },

        adaptiveSectionImg: function(el) {
            var $selector = $(el);
            if ($selector.length) {
                $selector.find('img').css('display', 'none');
                setResponiveBg();
            }

            function deviceMode(bp) {
                var _device = "m";
                var winWidth = $(window).width();
                if (winWidth > bp) {
                    _device = "d";
                }
                return _device;
            }

            function setResponiveBg() {
                var mode = deviceMode(540); // Breakpoint as Input Value | return "m" / "d"  | defult value "m"
                $selector.each(function() {
                    var _this = $(this);
                    var desktopImg = _this.find('img').attr('src');
                    var mobileImg = _this.find('img').data("mobilesrc");

                    if (typeof mobileImg !== 'undefined') {
                        _this.css("background-image", 'url("' + desktopImg + '")');
                        if (mode !== "d") {
                            _this.css("background-image", 'url("' + mobileImg + '")');
                        }
                    }

                    if (typeof mobileImg == 'undefined' || mobileImg == '') {
                        _this.css("background-image", 'url("' + desktopImg + '")');
                    }


                });

            }

        },


        datePickerBlock: function() {
            var dateMin = new Date();
            var weekDays = AddWeekDays(0);


            dateMin.setDate(dateMin.getDate() + weekDays);

            var natDays = [
                [1, 1, 'usa'],
                [12, 25, 'usa'],
                [12, 26, 'usa']
            ];

            function noWeekendsOrHolidays(date) {
                return nationalDays(date);

                /* var noWeekend = $.datepicker.noWeekends(date);                

                 if (noWeekend[0]) {
                     return nationalDays(date);
                 } else {
                     return noWeekend;
                 }*/
            }

            function nationalDays(date) {
                for (var i = 0; i < natDays.length; i++) {
                    if (date.getMonth() == natDays[i][0] - 1 && date.getDate() == natDays[i][1]) {
                        return [false, natDays[i][2] + '_day'];
                    }
                }
                return [true, ''];
            }

            function AddWeekDays(weekDaysToAdd) {
                var daysToAdd = 0
                var mydate = new Date()
                var day = mydate.getDay()
                weekDaysToAdd = weekDaysToAdd - (5 - day)
                if ((5 - day) < weekDaysToAdd || weekDaysToAdd == 1) {
                    daysToAdd = (5 - day) + 2 + daysToAdd
                } else { // (5-day) >= weekDaysToAdd
                    daysToAdd = (5 - day) + daysToAdd
                }
                while (weekDaysToAdd != 0) {
                    var week = weekDaysToAdd - 5
                    if (week > 0) {
                        daysToAdd = 7 + daysToAdd
                        weekDaysToAdd = weekDaysToAdd - 5
                    } else { // week < 0
                        daysToAdd = (5 + week) + daysToAdd
                        weekDaysToAdd = weekDaysToAdd - (5 + week)
                    }
                }

                return daysToAdd;
            }

            $('#datepicker').datepicker({
                inline: true,
                beforeShowDay: noWeekendsOrHolidays,
                altField: '#txtCollectionDate',
                showOn: "both",
                dateFormat: "mm/dd/yy",
                minDate: dateMin,
                onSelect: function(dateText, inst) {
                    var date = $(this).val();
                    $('.selected-date').html("<small>Date Selected</small>" + date);
                    $('.sel-date').html(date);
                    revokeButton('.btn-nxt-time')
                }
            });


            $('.slot-holder .cnt>ul>li').on('click', function() {
                revokeButton('.btn-nxt-visitor');
                var time = $(this).find('input').val();
                $('.selected-time').html("<small>Time Selected</small>" + time);
                $('.sel-time').html(time);

            });

            dateCarouselNav();

            $('#purchaseTicket').on('shown.bs.modal', function() {
                $('.btn-grey').click(function(e) {
                    return false;
                });
            });

            function revokeButton(el) {
                $(el).removeAttr("disabled");
                $(el).unbind('click');
                $(el).addClass('active');
            }

            inputValidate();
            confirmTickets();

            function inputValidate() {
                $(".visitor-count input.form-control").on("keypress keyup blur paste", function(event) {

                    var that = this;
                    //paste event 
                    if (event.type === "paste") {
                        setTimeout(function() {
                            $(that).val($(that).val().replace(/[^\d].+/, ""));
                        }, 100);
                    } else {

                        if (event.which < 7 || event.which > 8 && event.which < 48 || event.which > 57) {
                            event.preventDefault();
                        } else {
                            $(this).val($(this).val().replace(/[^\d].+/, ""));
                        }
                    }

                    if (event.type === "blur") {
                        var adultCount = parseInt($("input[name='adult']").val() || 0);
                        var seniorCount = parseInt($("input[name='senior']").val() || 0);
                        var studentCount = parseInt($("input[name='student']").val() || 0);
                        var childCount = parseInt($("input[name='child']").val() || 0);
                        var totalVisitors = adultCount + seniorCount + studentCount + childCount;
                        var standardTicketPrice = CnnTours.methods.standardTicketPrice();
                        var totalPrice = calculateTicketTotal(standardTicketPrice, adultCount, seniorCount, studentCount, childCount);

                        $('.total-visitors').html(totalVisitors);
                        $('.total-price').html(totalPrice);
                        $('.adult-count').html(adultCount);
                        $('.senior-count').html(seniorCount);
                        $('.student-count').html(studentCount);
                        $('.child-count').html(childCount);
                    }


                    if ($("input[name='adult']").val() || $("input[name='senior']").val() || $("input[name='student']").val() || $("input[name='child']").val()) {
                        $('.total-tickets').css("display", "inline-block");
                        revokeButton('.btn-nxt-confirm');
                    } else {
                        $('.total-tickets').css("display", "none");
                        $('.btn-nxt-confirm').removeClass('active');
                        $('.btn-nxt-confirm').attr('disabled', 'disabled');
                        $('.btn-nxt-confirm').click(function(e) {
                            return false;
                        });

                    }

                });
            }

            function confirmTickets() {
                var price = CnnTours.methods.standardTicketPrice();
                $('.adult-price').html("$" + price.adult + " x ");
                $('.senior-price').html("$" + price.senior + " x ");
                $('.student-price').html("$" + price.student + " x ");
                $('.child-price').html("$" + price.child + " x ");
            }

            function calculateTicketTotal(price, adultCount, seniorCount, studentCount, childCount) {
                return (price.adult * adultCount) + (price.senior * seniorCount) + (price.student * studentCount) + (price.child * childCount)
            }


            function dateCarouselNav() {
                var clickEvent = false;

                $('#ticketCarousel').on('click', '.nav a', function() {
                    clickEvent = true;
                    $('.nav li').removeClass('active');
                    $(this).parent().addClass('active');
                }).on('slid.bs.carousel', function(e) {
                    if (!clickEvent) {
                        var count = $('.nav').children().length - 1;
                        var current = $('.nav li.active');
                        current.removeClass('active').next().addClass('active');
                        var id = parseInt(current.data('slide-to'));
                        if (count == id) {
                            $('.nav li').first().addClass('active');
                        }
                    }

                    clickEvent = false;
                });
            }

            function ConvertFormToJSON(form) {

                var formData = {
                    'adult': adultCount,
                    'senior': seniorCount,
                    'student': studentCount,
                    'child': childCount
                };

            }


        },
        standardTicketPrice: function() {
            return {
                adult: 13,
                senior: 15,
                student: 15,
                child: 13
            }
        },

        accordianMenu: function() {

            if ($('#cnnAccordianMenu').length) {

                $('.menu-list a.page-scroll').on('click', function() {

                    $('#cnnAccordianMenu >li>ul').hide();
                    $('#cnnAccordianMenu li a .iconHolder').removeClass('active');
                });


                $('#cnnAccordianMenu >li>ul').hide();
                $('#cnnAccordianMenu li a > span.iconHolder').click(
                    function() {

                        var checkElement = $(this).parent().next();
                        if ((checkElement.is('ul')) && (checkElement.is(':visible'))) {

                            return false;
                        }
                        if ((checkElement.is('ul')) && (!checkElement.is(':visible'))) {
                            $('#cnnAccordianMenu ul:visible').slideUp('normal');
                            checkElement.slideDown('normal');
                            $('#cnnAccordianMenu li a .iconHolder').removeClass('active');
                            $(this).addClass('active');

                            return false;
                        }
                    }
                );

            }

        },

        menuHorizontalListOnActive: function() {
            $('.sub-menu-list li.active').parent().addClass('active');
        },

        faqQestionAnswer: function() {
            $("div.questionAnswer").find("span.plus-minus-icon").each(function(i) {
                if (i === 0) {
                    $(this).addClass('glyphicon-minus');
                    $(this).closest(".questionAnswer").find("div.faqAnswer:first").addClass("in");
                } else {
                    $(this).addClass('glyphicon-plus');
                }
            });
            var selectIds = $('.faqAnswer');
            $(function($) {
                selectIds.on('show.bs.collapse hidden.bs.collapse', function() {
                    $(this).prev().find('.glyphicon').toggleClass('glyphicon-plus glyphicon-minus');
                })
            });
        },

        expandSection: function() {
            $('.icon.full-screen, .btn-show').click(function() {

                $('.btn-show').text(function(i, text) {
                    return text === "Show More" ? "Show Less" : "Show More";
                })


                $('body').toggleClass('onExpand');
                $(this).parents('.cnn-zone').toggleClass('expanded');
                $('.icon.full-screen').find('.fa').toggleClass('fa-expand');
                $('.icon.full-screen').find('.fa').toggleClass('fa-compress');
                if (!$('.menu-horizontal').hasClass('fade') || $('.menu-horizontal').hasClass('flagged')) {
                    $('.menu-horizontal').toggleClass('fade');
                    $('.menu-horizontal').addClass('flagged');
                }


            });

            $('.cnn-zone .scrollable').each(function() {
                if ($(this).has_scrollbar()) {
                    $(this).parent().find('.icon.full-screen').css('display', 'block');
                    $(this).parent().find('.btn-show').css('display', 'inline-block')
                }

            });
        },

        scrollableContentHeight: function() {
            var winHeight = $(window).height();
            var mobileHeight = winHeight - 270;
            var deskHeight = winHeight - 430;

            if ($(window).width() <= 1129) {
                $('.cnn-boxyCont .scrollable').css("max-height", mobileHeight)
            } else {
                $('.cnn-boxyCont .scrollable').removeAttr('style')
                    //$('.cnn-boxyCont .scrollable').css("max-height", deskHeight);
            }
        },
        carouselFlip: function() {

            $("#eventEnquiry").on('shown.bs.modal', function() {
                if ($(".flipster").length) {
                    var flipContainer = $('.flipster'),
                        flipItemContainer = flipContainer.find('.flip-items'),
                        flipItem = flipContainer.find('li');

                    flipContainer.flipster({
                        itemContainer: flipItemContainer,
                        itemSelector: flipItem,
                        loop: 2,
                        start: 0,
                        style: 'infinite-carousel',
                        spacing: 1,
                        scrollwheel: false,
                        //nav: 'after',
                        buttons: false
                    });
                }


                var $currentSlide = $('.flip-items > .flipster__item--current')
                $('.next-btn').click(function() {
                    ($('.flip-items > .flipster__item--current').next().length) ? $('.flip-items > .flipster__item--current').next('li').stop().trigger('click'): $('.flip-items>li').first().stop().trigger('click');

                });
                $('.prev-btn').click(function() {
                    ($('.flip-items > .flipster__item--current').prev().length) ? $('.flip-items > .flipster__item--current').prev('li').stop().trigger('click'): $('.flip-items>li').last().stop().trigger('click');

                });
            });


        },

        translateIcon: function() {

            $('[data-toggle="tooltip"]').tooltip();

            var el = $('.trans-icon')

            el.click(function() {
                $(this).fadeOut();
                $('#google_translate_element').fadeIn();
            });

            $('html').click(function(e) {
                //if clicked element is not your element and parents aren't your div
                if (e.target.id != '#google_translate_element' && $(e.target).parents('.translate-wrapper').length == 0) {

                    $('.trans-icon').fadeIn();
                    $('#google_translate_element').fadeOut();
                }
            });


        },

        hasScrollBar: function() {
            $.fn.has_scrollbar = function() {
                var parentH = $(this).outerHeight();
                var childH = $(this).find('.content').prop('scrollHeight');
                if (childH > parentH)
                    return true;
            }
        },

        purchaseModalOverlay: function() {

            var winWidth = $(window).width();

            if (winWidth > 1129) {
                $('.btn-ticket').hover(function() {

                    $('.ticket-dropdown').addClass('showDrop');
                    var addAnim = setTimeout(addAnim, 200);

                    function addAnim() {
                        $('body').addClass('dropDownTicket');

                    }
                });


                $('.btn-ticket').click(function() {
                    $('#purchaseTicket').modal('show');
                    return false;
                });


            } else {
                $('.btn-ticket').click(function() {


                    $('.ticket-dropdown').addClass('showDrop');
                    var addAnim = setTimeout(addAnim, 200);

                    function addAnim() {
                        $('body').addClass('dropDownTicket');

                    }
                });
            }


            $('.close-hours-dropdown').click(function(event) {

                $('body').removeClass('dropDownTicket');
                setTimeout(addAnim, 200);
            });

            $('html').click(function(e) {
                //if clicked element is not your element and parents aren't your div
                if (e.target.id != '.ticket-dropdown' && $(e.target).parents('.btn-ticket').length == 0) {
                    $('body').removeClass('dropDownTicket');
                    setTimeout(addAnim, 200);
                }
            });

            function addAnim() {
                $('.ticket-dropdown').removeClass('showDrop');
            }

        },

        googleMapApi: function(el) {

            var map_canvas = document.getElementById(el);
            var center = new google.maps.LatLng(33.757916, -84.394776)
            var zoom = 16

            var map_options = {
                center: center,
                zoom: zoom,
                mapTypeId: google.maps.MapTypeId.ROADMAP,
                scrollwheel: true,
                zoomControl: true,
                scaleControl: false
            };

            var map = new google.maps.Map(map_canvas, map_options);

            var marker = new google.maps.Marker({
                position: center,
                map: map,
                title: 'CNN Studio Tours'
            });

            var getMarkerPos = marker.getPosition();

            function resetPos() {
                map.setZoom(zoom);
                map.setCenter(getMarkerPos);
            }

            marker.addListener('click', function() {
                resetPos();
            });

            google.maps.event.addListener(map, 'bounds_changed', function() {
                $('.reset-map').stop().fadeOut();
                var isPonterinView = map.getBounds().contains(marker.getPosition());
                if (isPonterinView === false) {
                    $('.reset-map').stop().fadeIn();
                }

            });

            $('.reset-map').click(function(event) {
                resetPos();
            });

        }
    }

    /**
     * run on document load
     */
    $(function() {
        CnnTours.methods.lazyload();
        CnnTours.methods.hiddenBodyScroll();
        CnnTours.methods.accordianMenu();
        CnnTours.methods.IeBugFixBootStrap();
        CnnTours.methods.scrollPageTop();
        CnnTours.methods.detectMobile();
        CnnTours.methods.offCanvasmenu();
        CnnTours.methods.dropDownAnimation();
        CnnTours.methods.pageScrolling();
        CnnTours.methods.hideBtnOnScroll();
        CnnTours.methods.autoScrollToNextSection('.cnn-zone');
        CnnTours.methods.toogleHorizontalMenu();
        CnnTours.methods.rippleEffect('.ripplelink');

        CnnTours.methods.searchToggle();

        CnnTours.methods.menuHorizontalListOnActive();
        CnnTours.methods.faqQestionAnswer();
        CnnTours.methods.datePickerBlock();
        CnnTours.methods.carouselFlip();
        CnnTours.methods.translateIcon();
        CnnTours.methods.hasScrollBar();
        CnnTours.methods.weatherWidget({
            widgetEl: "#weather-widget",
            apiKey: "69c164663f19b7c5",
            latitude: 33.757916,
            longitude: -84.394776,
            tempUnit: "fahrenheit" // "celsius" | "fahrenheit"
        });
        CnnTours.methods.weatherWidgetMobile({
            widgetEl: "#weather-mobile",
            apiKey: "69c164663f19b7c5",
            latitude: 33.757916,
            longitude: -84.394776,
            tempUnit: "fahrenheit" // "celsius" | "fahrenheit"
        });
        //CnnTours.methods.adaptiveSectionImg('.cnnSectionBg');
        CnnTours.methods.expandSection();
        CnnTours.methods.searchSecondary();


        /**
         * on resize
         */
        $(window).resize(function() {
            clearTimeout(window.resizedFinished);
            window.resizedFinished = setTimeout(function() {
                CnnTours.methods.cnnMenuLeftPos();
                CnnTours.methods.purchaseModalOverlay();
                CnnTours.methods.mapWrapperWidth();
                CnnTours.methods.matchWindowHeight('.setWinHeight');
                CnnTours.methods.scrollableContentHeight();
                CnnTours.methods.activeSectionToTop();
                CnnTours.methods.googleMapApi('googleMap');
            }, 450);
        }).trigger('resize');

    });

})();
