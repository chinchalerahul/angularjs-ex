<?php

/**
 * @file
 * Contains \Drupal\login_redirect\Controller\Login_redirectController
 */

namespace Drupal\login_redirect\Controller;

use Drupal\Core\Url;
// Change following https://www.drupal.org/node/2457593
use Drupal\Component\Utility\SafeMarkup;

/**
 * Controller routines for login_redirect pages.
 */
class Login_redirectController {

}
