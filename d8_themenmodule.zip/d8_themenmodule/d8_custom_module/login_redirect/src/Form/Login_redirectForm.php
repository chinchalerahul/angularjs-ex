<?php

namespace Drupal\login_redirect\Form;

use Drupal\Core\Form\ConfigFormBase;
use Drupal\Core\Form\FormStateInterface;

class Login_redirectForm extends ConfigFormBase {
  public function getFormId() {
    return 'login_redirect_form';
  }
  public function buildForm(array $form, FormStateInterface $form_state) {
		// Form constructor
		$form = parent::buildForm($form, $form_state);
    // Default settings
    $config = $this->config("login_redirect.settings");
		$form["login_url_administrator"] = array(
      '#type' => 'textfield',
      '#title' => $this->t('Redirection URL For Administrator :'),
      '#default_value' => $config->get('login_redirect.login_url_administrator'),
      '#description' => $this->t('Please enter the redirection url where you want to redirect the users.'),
    );
		$form["login_roles_administrator"] = array(
      '#type' => 'textfield',
      '#title' => $this->t('List of Roles:'),
      '#default_value' => $config->get('login_redirect.login_roles_administrator'),
      '#description' => $this->t('List of the roles for whom page needs to redirect. For ex: administrator'),
    );
		$form["login_url_anonymous"] = array(
      '#type' => 'textfield',
      '#title' => $this->t('Redirection URL for authenticated users. For ex: content_editor'),
      '#default_value' => $config->get('login_redirect.login_url_anonymous'),
      '#description' => $this->t('Please enter the redirection url where you want to redirect the users.'),
    );
		$form["login_roles_anonymous"] = array(
      '#type' => 'textfield',
      '#title' => $this->t('List of Roles:'),
      '#default_value' => $config->get('login_redirect.login_roles_anonymous'),
      '#description' => $this->t('List of the roles for whom page needs to redirect. For ex: content_editor'),
    );	
		return $form;
  }
	
	public function validateForm(array &$form, FormStateInterface $form_state) {

  }
  
	public function submitForm(array &$form, FormStateInterface $form_state) {
		$config = $this->config('login_redirect.settings');
    $config->set('login_redirect.login_url_administrator', $form_state->getValue('login_url_administrator'));
    $config->set('login_redirect.login_roles_administrator', $form_state->getValue('login_roles_administrator'));
		$config->set('login_redirect.login_url_anonymous', $form_state->getValue('login_url_anonymous'));
    $config->set('login_redirect.login_roles_anonymous', $form_state->getValue('login_roles_anonymous'));
    $config->save();
		return parent::submitForm($form, $form_state);
	}
	
	protected function getEditableConfigNames() {
    return [
      'login_redirect.settings',
    ];
  }

}